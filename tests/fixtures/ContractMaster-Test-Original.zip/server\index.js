const express = require('express');
const cors = require('cors');
const path = require('path');

// Import the problematic classes (multiple duplicates)
const MegaController = require('./controllers/MegaController');
const UserController = require('./controllers/UserController');
const { BusinessLogic } = require('./controllers/BusinessLogic');
const UserService = require('./services/UserService');
const UserManager = require('./services/user-service');
const { ProcessorFactory } = require('./services/ProcessorFactory');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize the problematic mega controller
const megaController = new MegaController();
const userController = new UserController();
const businessLogic = new BusinessLogic();

// Routes that demonstrate the issues
app.post('/api/users/register', (req, res) => {
    // Now using dedicated UserController (SRP compliant)
    userController.registerUser(req, res);
});

app.put('/api/users/:userId', (req, res) => {
    userController.updateUser(req, res);
});

app.delete('/api/users/:userId', (req, res) => {
    userController.deleteUser(req, res);
});

app.post('/api/contracts/create', (req, res) => {
    // This also uses the mega controller
    megaController.createContract(req, res);
});

app.post('/api/contracts/process', async (req, res) => {
    try {
        // This demonstrates DIP violation
        const result = await businessLogic.processContract(req.body);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/contracts/factory-test/:type', (req, res) => {
    try {
        // This demonstrates OCP violation
        const processor = ProcessorFactory.createProcessor(req.params.type, req.body);
        const result = processor.process();
        res.json({ result });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.get('/api/reports', (req, res) => {
    // Another SRP violation - reports through mega controller
    megaController.generateUserReport(req, res);
});

// Hello World endpoint
app.get('/api/hello', (req, res) => {
    res.json({ message: 'Hello, World!' });
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        service: 'ContractMaster Test API',
        issues: 'Contains intentional SOLID violations and duplicates for testing'
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        error: 'Something went wrong!',
        message: err.message,
        note: 'This server contains intentional design issues for testing CodeMind'
    });
});

app.listen(PORT, () => {
    console.log(`🚀 ContractMaster Test Server running on port ${PORT}`);
    console.log(`📄 Contains intentional issues for CodeMind testing:`);
    console.log(`   - SOLID principle violations`);
    console.log(`   - Duplicate classes with similar functionality`);
    console.log(`   - Poor separation of concerns`);
    console.log(`💊 Health: http://localhost:${PORT}/api/health`);
});
