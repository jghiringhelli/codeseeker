# ContractMaster Test Project

This is a **test project** specifically created for testing CodeMind's capabilities. It contains **intentional architectural issues** and **code problems** designed to evaluate CodeMind's:

- Duplicate detection and consolidation
- SOLID principles enforcement
- Context enhancement
- Task splitting intelligence
- Quality cycle monitoring

## ⚠️ INTENTIONAL ISSUES

This project deliberately contains the following problems:

### 1. Duplicate Classes
- **UserService** vs **user-service** vs **UserManager** - Three different user management implementations
- **ContractValidator** vs **contract-validator** vs **ValidatorService** - Multiple validation approaches
- **DatabaseHelper** vs **db-helper** vs **DatabaseUtil** - Three database utility classes

### 2. SOLID Violations

#### Single Responsibility Principle (SRP)
- `MegaController` handles users, contracts, emails, PDFs, and reports
- Should be split into focused controllers

#### Open/Closed Principle (OCP)
- `ProcessorFactory` requires modification for every new processor type
- Hardcoded switch statements

#### Liskov Substitution Principle (LSP)
- `NDAAgreement`, `EmploymentContract`, `ServiceAgreement` break parent contracts
- Cannot be substituted for `BaseContract` without issues

#### Interface Segregation Principle (ISP)
- `IServiceProvider` is a fat interface forcing implementations to depend on unused methods
- `SimpleUserService` must implement payment, email, and file methods it doesn't use

#### Dependency Inversion Principle (DIP)
- `BusinessLogic` depends directly on concrete implementations
- Hard-coded database, file system, and email dependencies

### 3. Poor Architecture
- Mixed concerns throughout the application
- Direct dependencies instead of abstractions
- No proper layer separation
- Inconsistent naming conventions

## Project Structure

```
ContractMaster-Test/
├── server/
│   ├── controllers/
│   │   ├── MegaController.js        # SRP violation
│   │   └── BusinessLogic.js         # DIP violation
│   ├── services/
│   │   ├── UserService.js           # Duplicate 1
│   │   ├── user-service.js          # Duplicate 2
│   │   ├── ProcessorFactory.js      # OCP violation
│   │   ├── IServiceProvider.js      # ISP violation
│   │   └── contract-validator.js    # Duplicate 2
│   ├── utils/
│   │   └── DatabaseHelper.js        # Duplicate 1
│   └── index.js                     # Server entry point
├── lib/
│   ├── core/
│   │   ├── UserManager.js           # Duplicate 3
│   │   ├── ContractTypes.js         # LSP violation
│   │   └── db-helper.js             # Duplicate 2
│   ├── validators/
│   │   └── ContractValidator.js     # Duplicate 1
│   └── helpers/
│       ├── ValidatorService.js      # Duplicate 3
│       └── DatabaseUtil.js          # Duplicate 3
├── tests/
│   └── contract.test.js             # Basic tests
└── package.json
```

## Testing CodeMind

This project is designed to test these CodeMind features:

1. **`codemind init`** - Initial analysis and indexing
2. **`codemind init --reset`** - Clean reinitialization
3. **`codemind dedup`** - Duplicate detection and merging
4. **`codemind solid`** - SOLID principles analysis
5. **Context enhancement** - Smart context for different scenarios
6. **Task splitting** - Breaking complex tasks into subtasks
7. **Quality monitoring** - Tracking improvements over time

## Expected CodeMind Results

### Duplicate Detection
Should identify:
- 3 user management classes that can be merged
- 3 validation classes with overlapping functionality
- 3 database utility classes doing similar work

### SOLID Analysis
Should detect:
- SRP violations in `MegaController`
- OCP violations in `ProcessorFactory`
- LSP violations in contract inheritance
- ISP violations in `IServiceProvider`
- DIP violations in `BusinessLogic`

### Refactoring Suggestions
Should recommend:
- Splitting `MegaController` into focused controllers
- Creating processor interfaces for extensibility
- Fixing inheritance hierarchies
- Breaking down fat interfaces
- Implementing dependency injection

## Installation

```bash
cd ContractMaster-Test
npm install
```

## Running the Server

```bash
npm start
```

The server will run on http://localhost:3000 with intentional issues for testing.

## Testing with CodeMind

Follow the testing protocol in `../CodeMind-Testing-Protocol.md` to run comprehensive tests on this project.

---

**Note**: This is a test project with intentional issues. Do not use as a reference for good code practices.