// DUPLICATE 1: Database utility helper
const fs = require('fs');
const path = require('path');

class DatabaseHelper {
    constructor(dbPath) {
        this.dbPath = dbPath || path.join(__dirname, '../../data/database.json');
        this.initializeDatabase();
    }

    initializeDatabase() {
        if (!fs.existsSync(this.dbPath)) {
            const initialData = {
                users: [],
                contracts: [],
                metadata: {
                    created: new Date().toISOString(),
                    version: '1.0.0'
                }
            };
            this.writeData(initialData);
        }
    }

    readData() {
        try {
            const data = fs.readFileSync(this.dbPath, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('Error reading database:', error);
            return null;
        }
    }

    writeData(data) {
        try {
            fs.writeFileSync(this.dbPath, JSON.stringify(data, null, 2));
            return true;
        } catch (error) {
            console.error('Error writing database:', error);
            return false;
        }
    }

    insertUser(userData) {
        const data = this.readData();
        if (!data) return null;

        const user = {
            id: Date.now(),
            ...userData,
            createdAt: new Date().toISOString()
        };

        data.users.push(user);
        this.writeData(data);
        return user;
    }

    findUser(id) {
        const data = this.readData();
        if (!data) return null;

        return data.users.find(user => user.id === id);
    }

    updateUser(id, updates) {
        const data = this.readData();
        if (!data) return false;

        const userIndex = data.users.findIndex(user => user.id === id);
        if (userIndex === -1) return false;

        data.users[userIndex] = { ...data.users[userIndex], ...updates };
        return this.writeData(data);
    }

    insertContract(contractData) {
        const data = this.readData();
        if (!data) return null;

        const contract = {
            id: Date.now(),
            ...contractData,
            createdAt: new Date().toISOString()
        };

        data.contracts.push(contract);
        this.writeData(data);
        return contract;
    }

    findContract(id) {
        const data = this.readData();
        if (!data) return null;

        return data.contracts.find(contract => contract.id === id);
    }

    queryContracts(filters = {}) {
        const data = this.readData();
        if (!data) return [];

        let contracts = data.contracts;

        if (filters.userId) {
            contracts = contracts.filter(c => c.userId === filters.userId);
        }

        if (filters.type) {
            contracts = contracts.filter(c => c.type === filters.type);
        }

        if (filters.status) {
            contracts = contracts.filter(c => c.status === filters.status);
        }

        return contracts;
    }
}

module.exports = DatabaseHelper;